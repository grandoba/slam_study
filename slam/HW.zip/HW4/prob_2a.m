clc; clear all;
time_frame = 100;
x = zeros(3, time_frame);
N = 100;
% Initial particles
px = normrnd(0, sqrt(0.01), [1,N]);
py = normrnd(0, sqrt(0.01), [1,N]);
pt = normrnd(0, sqrt(10000), [1,N]);
pt = mod(pt, 2*pi);
p = [px; py; pt];
mu = mean(p,2);

%% Part a
figure(1)
hold on;
plot(x(1,1), x(2,1), 'xr', "LineWidth",3);
plot(p(1,:), p(2,:),'.');
plot(mu(1,1), mu(2,1),'ob',"LineWidth",2);
for i=2:time_frame
    x(1,i) = x(1,i-1) + cos(x(3,i-1));
    x(2,i) = x(2,i-1) + sin(x(3,i-1));
    x(3,i) = x(3,i-1);
    plot(x(1,i), x(2,i), 'xr', "LineWidth",3);

    % Update particle pose
    p(1, :) = p(1, :) + cos(p(3,:));
    p(2, :) = p(2, :) + sin(p(3,:));
    mu = mean(p,2);
    % Resampling
    p = p(:, unidrnd(N,1,N));
    mu = mean(p,2);
    plot(p(1,:), p(2,:),'.');
    plot(mu(1,1), mu(2,1),'ob',"LineWidth",2);
end
hold off;

