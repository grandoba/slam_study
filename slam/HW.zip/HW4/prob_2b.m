%% Part b
clc; clear all;
rng(8);
time_frame = 100;
x = zeros(3, time_frame);
N = 50000;
P = [0.01 0 0; 0 0.01 0; 0 0 10000];
x_init = [0;0;0];
weight = ones(1, N);
R = [0.01 0 0; 0 0.01 0; 0 0 0.01];

% Initial particles
p = mvnrnd(x_init, P, N)';
p(3, :) = mod(p(3, :), 2*pi); 
mu = mean(p,2);
figure(2)
xlim([-1, time_frame + 1])
ylim([-1.0, 1.0])
hold on;
plot(x(1,1), x(2,1), 'xr', "LineWidth",3);
plot(p(1,:), p(2,:),'.');
plot(mu(1,1), mu(2,1),'ob',"LineWidth",2);

% Propagate over time frame
for i=2:time_frame
    x(1,i) = x(1,i-1) + cos(x(3,i-1));
    x(2,i) = x(2,i-1) + sin(x(3,i-1));
    x(3,i) = x(3,i-1);
    plot(x(1,i), x(2,i), 'xr', "LineWidth",3);
   
    % Propate particles
    p(1, :) = p(1, :) + cos(p(3,:));
    p(2, :) = p(2, :) + sin(p(3,:));
%     p(1, :) = normrnd(p(1,:), sqrt(0.01));
%     p(2, :) = normrnd(p(2,:), sqrt(0.01));
%     p(3, :) = normrnd(p(3,:), sqrt(10000));

    % Resampling
    weight = mvnpdf(p', x(:, i)', R)';
    sample_idx = randsample(N, N, true, weight)';
    p = p(:, sample_idx);
    mu = mean(p,2);

    plot(p(1,:), p(2,:),'.');
    plot(mu(1,1), mu(2,1),'ob',"LineWidth",2);
    
end
hold off;
