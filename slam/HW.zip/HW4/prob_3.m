rng(3);
x0 = [0 0 2.0 -0.5];
p1 = [500 -100];
p2 = [500 0];
p3 = [500 100];
p4 = [500 200];
R = eye(4);
A = [1 0 1 0; 0 1 0 1; 0 0 1 0; 0 0 0 1];
time_frame = 100;
x = zeros(100, 4);
target = zeros(100, 4);
z = zeros(100, 4);
x(1,:) = x0;
% x(1,:) = [0 0 0 0];
target(1,:) = x0;
mu = x(1,:);
P = eye(4)*1000;

figure()
xlim([-80,220]);
ylim([-60, 40]);
hold on;

% Random position with initial cov
x(1,:) = mvnrnd(mu, P, 1);
z(1,:) = [dist(target(1,:),p1) dist(target(1,:), p2) dist(target(1,:), p3) dist(target(1,:), p4)];
draw_ellipse(x(1,1:2), P(1:2,1:2), 0.90);

for i=2:time_frame
    % State propagation
    target(i,:) = (A*(target(i-1,:)'))';
    % State estimate propagation
    x(i,:) = (A*(x(i-1,:)'))';

    % Error covariance propagation
    P = A*P*A';
    % Measurement
    z(i,:) = hx(target(i,:), [p1;p2;p3;p4]);
    % Measurement matrix
    H = H_jacobian(x(i,:), [p1;p2;p3;p4]);
    % Kalman gain
    K = P*H'*inv(H*P*H' + R);
    % Error covariance update
    P = (eye(4)-K*H)*P;
    % State estimate update by measurement
    est_z = hx(x(i,:), [p1;p2;p3;p4]);
    x(i,:) = (x(i,:)'+K*(z(i,:)'-est_z'))';
    % Draw 90% interval ellipse
    draw_ellipse(x(i,1:2), P(1:2,1:2), 0.90);
end
quiver(x(:,1),x(:,2),x(:,3), x(:,4), 'k');
plt1 = plot(target(:,1), target(:,2), 'xr');
plt2 = plot(x(:,1), x(:,2), '.b',"LineWidth",5);
legend([plt1 plt2],'Target','Tracker');
hold off;

function d = dist(state, beacon)
    d = norm(state(1:2)-beacon);
end

function H = H_jacobian(state, beacons)
    H = zeros(4);
    for i=1:length(beacons)
        b = beacons(i,:);
        H(i,1) = (state(1)-b(1)) / norm(state(1:2) - b);
        H(i,2) = (state(2)-b(2)) / norm(state(1:2) - b);
        H(i,3) = H(i,1);
        H(i,4) = H(i,2);
    end
end

function z_est = hx(x, beacons)
    z_est = [dist(x, beacons(1,:)) dist(x, beacons(2,:)) ...
                dist(x,beacons(3,:)) dist(x, beacons(4,:))];
end

function sample = ellipsoid_ci(mu, cov, ci)
    alpha = chi2inv(ci, 2);
    cov = round(cov,4);
    while true
        sample = mvnrnd(mu,cov,1);
        S = (sample-mu)*inv(cov)*(sample-mu)';
        if S <= alpha
            break
        end
    end
end

function draw_ellipse(mu, cov, ci)
    alpha = chi2inv(ci, 2);
    cov = round(cov,4);
    syms x y;
    ellipse = @(x, y) ([x y] - mu)/(cov)*([x y] - mu)' - alpha;
    fimplicit(ellipse,'g-');
end